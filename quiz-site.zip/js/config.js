/** Configuration NON secrète. Collez ici l'URL de déploiement du Web App Apps Script. */
window.CONFIG = { API_URL: 'COLLER_URL_APPS_SCRIPT_ICI' };
