/** Backend Google Apps Script — lié au classeur Google Sheets (Extensions > Apps Script).
 *  Feuilles : Quiz, Questions, Resultats, Utilisateurs. Voir README.md. */
const SS = SpreadsheetApp.getActive();
const SESSION_TTL = 21600; // 6 h (maximum du CacheService)

function doPost(e) {
  let out;
  try { out = route(JSON.parse(e.postData.contents)); }
  catch (err) { out = { ok: false, error: err.message }; }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

function route(b) {
  if (b.action === 'login') return login(b);
  const u = auth(b.token);
  switch (b.action) {
    case 'me': return { ok: true, user: pub(u) };
    case 'quizzes': return { ok: true, quizzes: listQuizzes() };
    case 'questions': return { ok: true, questions: listQuestions(b.quiz_id).map(publicQuestion) };
    case 'grade': return grade(b);
    case 'finish': return finish(u, b);
    case 'results': return { ok: true, results: rows('Resultats').filter(r => r.utilisateur_id === u.user_id) };
    case 'updateProfile': setRow('Utilisateurs', 'user_id', u.user_id, { nom: String(b.nom || '').slice(0, 60) }); return { ok: true };
    case 'changePassword': return changePassword(u, b);
    case 'logout': CacheService.getScriptCache().remove('s_' + b.token); return { ok: true };
  }
  throw new Error('Action inconnue');
}

/* ---------- Utilitaires feuilles ---------- */
function rows(name) {
  const v = SS.getSheetByName(name).getDataRange().getValues(), h = v.shift();
  return v.filter(r => r.join('') !== '').map(r => Object.fromEntries(h.map((k, i) => [k, r[i]])));
}
function setRow(name, keyCol, keyVal, obj) {
  const sh = SS.getSheetByName(name), v = sh.getDataRange().getValues(), h = v[0], k = h.indexOf(keyCol);
  for (let i = 1; i < v.length; i++) if (v[i][k] === keyVal) {
    Object.keys(obj).forEach(c => sh.getRange(i + 1, h.indexOf(c) + 1).setValue(obj[c]));
    return;
  }
  throw new Error('Ligne introuvable');
}
const isActive = v => v === true || /^(true|oui|vrai|1)$/i.test(String(v).trim());

/* ---------- Authentification (hash salé, jamais de mot de passe en clair) ---------- */
function hash(salt, pw) {
  let h = salt + pw;
  for (let i = 0; i < 1000; i++) h = Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, h + salt));
  return h;
}
/** À exécuter depuis l'éditeur : creerUtilisateur('moi@mail.fr', 'Prénom', 'motdepasse') */
function creerUtilisateur(email, nom, motDePasse) {
  const salt = Utilities.getUuid();
  SS.getSheetByName('Utilisateurs').appendRow([Utilities.getUuid(), email.toLowerCase(), nom, salt, hash(salt, motDePasse)]);
}
function login(b) {
  const u = rows('Utilisateurs').find(r => String(r.email).toLowerCase() === String(b.email).trim().toLowerCase());
  Utilities.sleep(400); // freine le brute-force
  if (!u || hash(u.sel, String(b.password)) !== u.hash) return { ok: false, error: 'Identifiant ou mot de passe incorrect.' };
  const token = Utilities.getUuid() + Utilities.getUuid();
  CacheService.getScriptCache().put('s_' + token, u.user_id, SESSION_TTL);
  return { ok: true, token, user: pub(u) };
}
function auth(token) {
  const id = token && CacheService.getScriptCache().get('s_' + token);
  const u = id && rows('Utilisateurs').find(r => r.user_id === id);
  if (!u) throw new Error('SESSION_EXPIREE');
  return u;
}
const pub = u => ({ user_id: u.user_id, email: u.email, nom: u.nom });
function changePassword(u, b) {
  if (hash(u.sel, String(b.ancien)) !== u.hash) return { ok: false, error: 'Mot de passe actuel incorrect.' };
  if (String(b.nouveau).length < 8) return { ok: false, error: '8 caractères minimum.' };
  const salt = Utilities.getUuid();
  setRow('Utilisateurs', 'user_id', u.user_id, { sel: salt, hash: hash(salt, String(b.nouveau)) });
  return { ok: true };
}

/* ---------- Quiz & questions ---------- */
function listQuizzes() {
  const qs = rows('Questions').filter(q => isActive(q.actif));
  return rows('Quiz').filter(q => isActive(q.actif)).map(q => ({
    quiz_id: q.quiz_id, nom: q.nom, description: q.description,
    nb_questions: qs.filter(x => x.quiz_id === q.quiz_id).length
  }));
}
function listQuestions(quizId) {
  return rows('Questions').filter(q => q.quiz_id === quizId && isActive(q.actif))
    .sort((a, b) => a.ordre - b.ordre);
}
const expectedIdx = q => String(q.reponse_attendue).split(',').map(s => Number(s.trim())).sort();
/** Les réponses attendues et explications ne sont JAMAIS envoyées ici. */
function publicQuestion(q) {
  const choix = q.type === 'qcm' ? String(q.choix).split('|').map(s => s.trim()) : [];
  return {
    question_id: q.question_id, type: q.type, enonce: q.enonce, image_url: q.image_url || '',
    choix, multiple: q.type === 'qcm' && expectedIdx(q).length > 1,
    points: Number(q.points) || 1, correction_type: q.correction_type || 'auto'
  };
}
const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  .replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();

/** Correction côté serveur. Libre « auto » : égalité normalisée avec l'une des variantes séparées par « | ».
 *  Libre « manuelle » : l'utilisateur s'auto-évalue (selfOk). */
function gradeOne(q, answer, selfOk) {
  const pts = Number(q.points) || 1;
  let ok = false;
  if (q.type === 'qcm') {
    const given = (answer || []).map(Number).sort(), exp = expectedIdx(q);
    ok = given.length === exp.length && given.every((v, i) => v === exp[i]);
  } else if (q.correction_type === 'manuelle') ok = !!selfOk;
  else ok = String(q.reponse_attendue).split('|').some(v => norm(v) === norm(answer || '') && norm(v) !== '');
  return { correct: ok, points: ok ? pts : 0 };
}
function attendueText(q) {
  if (q.type !== 'qcm') return String(q.reponse_attendue).split('|')[0];
  const ch = String(q.choix).split('|').map(s => s.trim());
  return expectedIdx(q).map(i => ch[i - 1]).join(' ; ');
}
function grade(b) {
  const q = rows('Questions').find(r => r.question_id === b.question_id);
  if (!q) throw new Error('Question introuvable');
  const base = { ok: true, attendue: attendueText(q), explication: q.explication || '' };
  if (q.type === 'libre' && q.correction_type === 'manuelle') return Object.assign(base, { manual: true, points_max: Number(q.points) || 1 });
  return Object.assign(base, gradeOne(q, b.answer));
}

/** Recalcule le score côté serveur à partir des réponses brutes et enregistre une tentative (idempotent via attempt_id). */
function finish(u, b) {
  const lock = LockService.getScriptLock(); lock.waitLock(10000);
  try {
    const existing = rows('Resultats').find(r => r.resultat_id === b.attempt_id);
    if (existing) return { ok: true, result: existing };
    const qs = listQuestions(b.quiz_id);
    if (!qs.length) throw new Error('Quiz sans questions');
    const ans = Object.fromEntries((b.answers || []).map(a => [a.question_id, a]));
    let got = 0, max = 0;
    qs.forEach(q => { max += Number(q.points) || 1; const a = ans[q.question_id]; if (a) got += gradeOne(q, a.answer, a.self_ok).points; });
    const res = {
      resultat_id: b.attempt_id, utilisateur_id: u.user_id, quiz_id: b.quiz_id, date: new Date().toISOString(),
      score_obtenu: got, score_max: max, pourcentage: Math.round(1000 * got / max) / 10,
      duree_secondes: Math.max(0, Math.round(Number(b.duree) || 0)), statut: 'Terminé'
    };
    SS.getSheetByName('Resultats').appendRow(Object.keys(res).map(k => res[k]));
    return { ok: true, result: res };
  } finally { lock.releaseLock(); }
}
