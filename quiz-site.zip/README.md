# Site de révision par quiz — HTML/CSS/JS natif + Google Apps Script

## 1. Architecture
Navigateur (pages statiques) → `js/api.js` → **Apps Script Web App** (auth, correction, scores) → **Google Sheets**.
Les mots de passe sont hachés (SHA-256 salé, 1000 itérations) côté serveur. Le navigateur ne garde qu'un jeton de session (valide 6 h).
Les réponses attendues ne quittent jamais le serveur avant la validation d'une question. Le score final est **recalculé côté serveur**.

## 2. Configuration Google Sheets
Créez un classeur avec 4 feuilles (1re ligne = en-têtes exacts) :
- **Quiz** : `quiz_id | nom | description | actif`
- **Questions** : `question_id | quiz_id | ordre | type | enonce | image_url | choix | reponse_attendue | explication | points | correction_type | actif`
- **Resultats** : `resultat_id | utilisateur_id | quiz_id | date | score_obtenu | score_max | pourcentage | duree_secondes | statut`
- **Utilisateurs** : `user_id | email | nom | sel | hash`

Formats : `choix` = `A|B|C|D` ; QCM `reponse_attendue` = numéros 1-based (`2` ou `1,3` → réponses multiples) ; libre `auto` = variantes séparées par `|` ; libre `manuelle` = réponse de référence (auto-évaluation). `actif` = TRUE/oui.

## 3. Backend
1. Classeur > Extensions > Apps Script, collez `apps-script/Code.gs`.
2. Exécutez `creerUtilisateur('vous@mail.fr','Prénom','MotDePasse8+')` (autorisez l'accès). Pour supprimer ce mot de passe du code, retirez l'appel ensuite.
3. Déployer > Nouveau déploiement > Application Web : exécuter en tant que **Moi**, accès **Tout le monde** (l'accès aux données est protégé par le jeton). Copiez l'URL `/exec`.
4. Collez cette URL dans `js/config.js`. Après toute modification de `Code.gs`, redéployez une nouvelle version.

## 4. Déploiement du site
Hébergez le dossier en HTTPS (GitHub Pages, Netlify…). Ouvrez `index.html`. Tests de calcul : `settings.html#tests` (console).

## 5. Données de démonstration (à remplacer)
Quiz : `demo1 | Culture générale (démo) | Quiz de démonstration | TRUE`
Questions :
- `q1 | demo1 | 1 | qcm | Capitale de la France ? | | Lyon|Paris|Nice | 2 | Paris est la capitale. | 1 | auto | TRUE`
- `q2 | demo1 | 2 | qcm | Nombres premiers ? | | 2|4|7|9 | 1,3 | 2 et 7 sont premiers. | 2 | auto | TRUE`
- `q3 | demo1 | 3 | libre | Plus grand océan ? | | | Pacifique|Océan Pacifique | | 1 | auto | TRUE`
- `q4 | demo1 | 4 | libre | Expliquez la photosynthèse. | | | Les plantes convertissent lumière, eau et CO2 en sucres et O2. | | 3 | manuelle | TRUE`

## 6. Limites connues
- Sessions limitées à 6 h (CacheService) ; Apps Script est lent (~1 s par appel).
- Correction libre « auto » = égalité exacte après normalisation (pas de correction sémantique) ; « manuelle » = auto-évaluation, donc non vérifiable.
- Pas d'enregistrement des tentatives interrompues, pas de réinitialisation de mot de passe oubliée.
- Préférences stockées localement (non synchronisées entre appareils).
- Non testé sur un vrai classeur : faites un essai complet après configuration.
